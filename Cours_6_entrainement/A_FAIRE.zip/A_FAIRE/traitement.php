<?php


// Vérification si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Trouver ici un moyen d'afficher les valeurs du formulaires

} else {
    die("Accès non autorisé !");
}


?>